print("!!Welcome to NITS Electronics!!")

Android_TV = 15000
Washing_Machine = 18000
Air_conditioner = 35000
Oven = 9000
Fridge = 25000
Smart_TV = 27000

print("Android_TV = 15000")
print("Washing_Machine = 18000")
print("Air_conditioner = 35000")
print("Oven = 9000")
print("Fridge = 25000")
print("Smart_TV = 27000")

product = input("What would you like to buy?: ")

products = [
    ("Android_TV", Android_TV),
    ("Washing_Machine", Washing_Machine),
    ("Air_conditioner", Air_conditioner),
    ("Oven", Oven),
    ("Fridge", Fridge),
    ("Smart_TV", Smart_TV)
]

for product_name, price in products:
    if product == product_name:
        quantity = int(input("How many quantity of do you want?: "))
        total_price = price * quantity
        print("Total Price of Product is:", total_price)
        print("Thanks for visiting NITS electronics")
        break
else:
    print("This Product Is Not Available")
