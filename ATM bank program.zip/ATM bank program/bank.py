login_pin = 4568
transaction_pin = 1179
balance = 10000

print("Welcome to the Bank")

entered_pin = int(input("Enter your four digit login pin: "))

if entered_pin == login_pin:
    print("Login successful.")
    print("Hello")
    print("Your available balance:", balance) 

    withdraw_amount = int(input("How much do you want to withdraw?: "))

    entered_trans_pin = int(input("Enter your four digit transaction pin: "))

    if entered_trans_pin == transaction_pin:
        if withdraw_amount > 0 and withdraw_amount <= balance:
            balance -= withdraw_amount
            print("Transaction successful")
            print("Your available balance:", balance)
        else:
            print("Invalid withdrawal amount")
    else:
        print("Incorrect transaction pin")

else:
    print("Incorrect login pin") 

