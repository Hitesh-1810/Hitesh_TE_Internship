a = []
for i in range(7):
    b= int(input("enter no into list:"))
    a.append(b)
    print("list a values:", a)
