b=["hit"]
l=["esh"]
b.extend(l)
print(b)