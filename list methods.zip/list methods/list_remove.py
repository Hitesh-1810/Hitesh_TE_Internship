a = [1,2,3,4,5]
a.remove(4)
print(a)