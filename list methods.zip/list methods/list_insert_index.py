l1 = [1,2,3,4]
l1.insert(5,9)
print(l1)
print(l1.index(3))