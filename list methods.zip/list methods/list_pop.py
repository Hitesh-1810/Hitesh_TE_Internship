a = [3,5,1,4,2]
b=[1,2,3,4,5]
a.pop(3) 
b.pop()
print(a)
print(b)