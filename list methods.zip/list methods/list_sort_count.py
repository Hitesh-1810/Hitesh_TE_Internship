a=[9,4,5,2,6,1,7,3]
a.sort()
print(a)
print(a.count(2))