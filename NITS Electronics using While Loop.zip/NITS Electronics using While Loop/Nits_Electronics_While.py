print("!!Welcome to NITS Electronics!!")
Android_TV = 15000
Washing_Machine = 18000
Air_conditioner = 35000
Oven = 9000
Fridge = 25000
Smart_TV = 27000
print("Android_TV = 15000")
print("Washing_Machine = 18000")
print("Air_conditioner = 35000")
print("Oven = 9000")
print("Fridge = 25000")
print("Smart_TV = 27000")
while (True):
    product = input("What would you like to buy?: ")

    if product == "Android_TV":
        price = Android_TV
        quantity = int(input("How many quantity do you want?: "))
        Total_price = price * quantity
        print("Total Price of Product is:", Total_price)
        print("Thanks for visiting NITS electronics")
        option = input("Do you want to continue with NITS electronics?(yes / no):")
        if option == "yes":
            print("Wellcome to continue NITS electronics")
            
        elif option == "no":
            print("Ok, for visiting NITS electronics")
            exit()


    elif product == "Washing_Machine":
        price = Washing_Machine
        quantity = int(input("How many quantity do you want?: "))
        Total_price = price * quantity
        print("Total Price of Product is:", Total_price)
        print("Thanks for visiting NITS electronics")
        option = input("Do you want to continue with NITS electronics?(yes / no):")
        if option == "yes":
            print("Wellcome to continue NITS electronics")
            
        elif option == "no":
            print("Ok, for visiting NITS electronics")
            exit()

    elif product == "Air_conditioner":
        price = Air_conditioner
        quantity = int(input("How many quantity do you want?: "))
        Total_price = price * quantity
        print("Total Price of Product is:", Total_price)
        print("Thanks for visiting NITS electronics")
        option = input("Do you want to continue with NITS electronics?(yes / no):")
        if option == "yes":
            print("Wellcome to continue NITS electronics")
            
        elif option == "no":
            print("Ok, for visiting NITS electronics")
            exit()

    elif product == "Oven":
        price = Oven
        quantity = int(input("How many quantity do you want?: "))
        Total_price = price * quantity
        print("Total Price of Product is:", Total_price)
        print("Thanks for visiting NITS electronics")
        option = input("Do you want to continue with NITS electronics?(yes / no):")
        if option == "yes":
            print("Wellcome to continue NITS electronics")
            
        elif option == "no":
            print("Ok, for visiting NITS electronics")
            exit()

    elif product == "Fridge":
        price = Fridge
        quantity = int(input("How many quantity do you want?: "))
        Total_price = price * quantity
        print("Total Price of Product is:", Total_price)
        print("Thanks for visiting NITS electronics")
        option = input("Do you want to continue with NITS electronics?(yes / no):")
        if option == "yes":
            print("Wellcome to continue NITS electronics")
            
        elif option == "no":
            print("Ok, for visiting NITS electronics")
            exit()

    elif product == "Smart_TV":
        price = Smart_TV
        quantity = int(input("How many quantity do you want?: "))
        Total_price = price * quantity
        print("Total Price of Product is:", Total_price)
        print("Thanks for visiting NITS electronics")
        option = input("Do you want to continue with NITS electronics?(yes / no):")
        if option == "yes":
            print("Wellcome to continue NITS electronics")
            
        elif option == "no":
            print("Ok, for visiting NITS electronics")
            exit()

    else:
        product = print("This Product Is Not Available buy a another product")
        
        
