print("******!!Wellcome to car rental website!!*******")
deposit_SUV = 1000
deposit_Sedan = 500
deposit_MPV = 1500
rent_SUV =5000
rent_Sedan =20000
rent_MPV =10000
print("Available car Brands: \nSUV\nSEDAN\nMPV\n")
Brand= input("enter the brand for rent: ")
while(True):
    if Brand == "SUV":
        print("SUV Available varieties: \ncreata\nkia\nscorpia\nthar\n")
        car = input("Enter the variety of car for rent: ")
        days = int(input("Enter the number of days to rent: "))
        total_bill = rent_SUV * days + deposit_SUV
        print("Total Bill:", total_bill)
        exit()
        
    elif Brand == "SEDAN":
        print("SEDAN Available varieties: \nsuziki\nskoda\nversa\nvolkswagan\n")
        car = input("Enter the variety of car for rent: ")
        days = int(input("Enter the number of days to rent: "))
        total_bill = rent_Sedan * days + deposit_Sedan
        print("Total Bill:", total_bill)
        exit()
        
    elif Brand == "MPV":
        print("MPV Available varieties: \ninova\nertiga\ninjecto\nlexus\n")
        car = input("Enter the variety of car for rent: ")
        days = int(input("Enter the number of days to rent: "))
        total_bill = rent_MPV * days + deposit_MPV
        print("Total Bill:", total_bill)
        exit()
        
    else:
        print("sorry, this type car brands not available")
        
    
    
        



