import matplotlib.pyplot as plt

# Data
x = [1, 2, 3]
y = [4, 5, 6]

# Scatter plot
plt.scatter(x, y)

plt.show()
