import matplotlib.pyplot as plt

labels = ['Apple', 'Banana', 'Orange', 'Grapes']
sizes = [40, 30, 20, 10]

plt.pie(sizes, labels=labels, autopct='%1.1f%%', startangle=90)
plt.show()
