# write a python program to check whether an element exists within a tuple#
tup = (10, 20, 30, 40, 50)
element = 30

if element in tup:
    print(f"{element} exists in the tuple.")
else:
    print(f"{element} does not exist in the tuple.")
