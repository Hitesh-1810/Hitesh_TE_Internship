# sum of all element in list#
A = [10, 20, 30, 40, 50]
total = 0
for i in A:
    total += i
print("sum of element in list:",total)