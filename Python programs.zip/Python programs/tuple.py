
tup = (10, 20, 30, 40, 50, 60)

if len(tup) >= 4:
    
    fourth_from_last = tup[-4]
    print("The 4th element from the last is:", fourth_from_last)
else:
    print("The tuple doesn't have enough elements.")
