def filter_strings_by_length(strings, length):
    result = []
    
    
    for string in strings:
        
        if len(string) > length:
            
            result.append(string)
    
    return result

strings = ["apple", "banana", "kiwi", "cherry", "mango"]
length = 5

filtered_strings = filter_strings_by_length(strings, length)

print("Strings with more than", length, "characters:", filtered_strings)
