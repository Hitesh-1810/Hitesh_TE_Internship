# write a python script to generate and print a dictionary that contains a number(bet 1 & n)
# in the form (x,x*x). sample dictionary(n=5): 

def generate_square_dict(n):
    result = {}
    for x in range(1, n+1):
        result[x] = x * x
    return result

n = 5
square_dict = generate_square_dict(n)
print("Generated Dictionary:", square_dict)
