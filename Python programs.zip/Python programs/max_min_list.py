def find_large_small(numbers):
    
    large = numbers[0]
    small = numbers[0]
    
    for num in numbers:
        if num > large:
            large = num
        if num < small:
            small = num
    
    return large, small

numbers = [12, 4, 56, 7, 89, 23]
large, small = find_large_small(numbers)
print("Largest number from list:", large)
print("Smallest number from list:", small)
