import pandas as pd
a = [1, 3, 5]
b=pd.Series(a)
c=pd.DataFrame(a)
print(b)
print("-----------------------")
print(c)

