print("=======SET METHODS=======\n")
# ADD METHOD#
fruits = {"apple", "banana", "cherry"}
fruits.add("orange")
print("ADD METHOD OUTPUT:",fruits)
# CLEAR METHOD#
clear_set = {"apple", "banana", "cherry"}
clear_set.clear()
print("CLEAR METHOD OUTPUT:",clear_set)
# COPY METHOD#
ID = {1, 2, 3}
L = ID.copy()
print("COPY METHOD OUTPUT:",L)
# DIFFERENCE METHOD#
x = {"AND", "OR", "NOT"}
y = {"OR", "A", "B"}
z = x.difference(y) 
print("DIFFERENCE METHOD OUTPUT:",z)
# DISCARD METHOD#
D = {1, "ABC", 3}
D.discard(3)
print("DISCARD METHOD OUTPUT:",D)
# INTERSECTION METHOD#
I1 = {"AND", "OR", "NOT"}
I2 = {"OR", "A", "B"}
I3 = I1.intersection(I2) 
print("INTERSECTION METHOD OUTPUT:",I3)
# DIFFERENCE_UPDATE METHOD#
d1 = {123, 321, 213}
d2 = {"423", "321", "apple"}
d1.difference_update(d2) 
print("DIFFERENCE_UPDATE METHOD OUTPUT:",d1)
# INTERSECTION_UPDATE METHOD#
g = {"apple", "banana", "cherry"}
j = {"google", "microsoft", "apple"}
g.intersection_update(j) 
print("INTERSECTION_UPDATE METHOD OUTPUT:",g)
# isdisjoint method#
n1 = {"apple", "banana", "cherry"}
n2 = {"vivo", "microsoft", "facebook"}
n3 = {"cherry", 1, 2}
n4 = n1.isdisjoint(n2) 
n5 = n1.isdisjoint(n3)
print("isdisjoint method outputs:",n4,",",n5)
# issubset method#
z1 = {"a", "b", "c"}
z2 = {"f", "e", "d", "c", "b", "a"}
z3 = z1.issubset(z2) 
z4 = z2.issubset(z1) 
print("issubset method output:",z3,",",z4)
# issuperset method#
ss1 = {"f", "e", "d", "c", "b", "a"}
ss2 = {"a", "b", "c"}
u = ss1.issuperset(ss2) 
print("issuperset method output:",u)
# pop method#
fruits = {"apple", "banana", "cherry"}
fruits.pop() 
print("pop method output:",fruits)
# remove method#
f1 = {"apple", "banana", "cherry"}
f1.remove("banana") 
print("remove method output:",f1)
# symmetric difference#
k1 = {"apple", "banana", "cherry"}
k2 = {"google", "microsoft", "apple"}
k3 = k1.symmetric_difference(k2) 
print("symmetric_diffderence output:",k3)
# union method#
category1 = {"apple", "banana", "cherry"}
category2 = {"google", "microsoft", "apple"}
C3 = category1.union(category2) 
print("union method output:",C3)
# update method#
h1 = {"apple", "banana", "cherry"}
h2 = {"google", "microsoft", "apple"}
h1.update(h2) 
print("update method output:\n",h1,"\n")


