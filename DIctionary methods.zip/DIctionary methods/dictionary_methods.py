print("==========DICTIONARY METHODS OUTPUTS===========\n")
# CLEAR METHOD#
D1 = {"a": 1, "b": 2, "c": 3}
D1.clear()
print("CLEAR METHOD OUTPUT:",D1,"\n")  
# COPY METHOD#
C1 = {"a":1, "b":2}
C1.copy()
print("COPY METHOD OUTPUT:",C1,"\n")
# FROMKEY METHOD#
fk = ["a", "b", "c"]
d = dict.fromkeys(fk, 8)
print("FROMKEY METHOD OUTPUT:",d,"\n")
# GET METHOD#
num = {"A":1, "B":2, "C":3, "D":4}
x = num.get("A")
y = num.get("B")
z = num.get("C")
l = num.get("D")
m = num.get("")
print("GET METHOD OUTPUT:", x , y, z, l, m,"\n")
# ITEMS METHOD#
record = {"ID":1, "NAME":"XYZ", "ADDRESS":"NSK"}
k = record.items()
print("ITEMS METHOD OUTPUT:",k,"\n")
# KEYS METHOD#
key_stud = {"ABC":1, "xyz":2, "ack":3}
d2= key_stud.keys()
print("KEYS METHOD OUTPUT:",d2,"\n")
# POP METHOD#
P1 = {"PART1":"GOOD", "PART2":"VERRY GOOD", "PART3":"EXCELLENT"}
P1.pop("PART1")
print("POP METHOD OUTPUT:",P1,"\n")
# POPITEM METHOD#
PI2 = {"id1":5, "id2":8, "id3":3}
PI2.popitem()
print("POPITEM METHOD OUTPUT:",PI2,"\n")
# SET DEFAULT METHOD#
SD = {"a": 1}
SD.setdefault("b", 2)  
print("SET DEFUALT METHOD OUTPUT:",SD,"\n") 
# UPDATE METHOD#
info = {"size":"large"}
info.update({"color": "White"})
print("UPDATE METHOD OUTPUT:",info,"\n")
# VALUES METHOD#
V1 = {"ABC":1, "xyz":2, "ack":3}
print("VALUES METHOD OUTPUT:", V1.values(),"\n")