print("=======TUPLES METHODS=======\n")
# COUNT METHOD#
count_tuple = (1, 2, 2, 3, 4, 2)
x = count_tuple.count(2)
print("COUNT METHOD OUTPUT:",x,"\n")
# INDEX METHOD#
index_tuple = (10, 20, 30, 40, 50, 60, 70)
I = index_tuple.index(30)
print("INDEX METHOD OUTPUT:",I,"\n")